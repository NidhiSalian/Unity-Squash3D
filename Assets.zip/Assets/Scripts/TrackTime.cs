﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class TrackTime : MonoBehaviour
{
    public static float time_counter;
    // Start is called before the first frame update
    void Start()
    {
        StartCoroutine(startTimer(350));
    }

    IEnumerator startTimer(float reloadTimeInSeconds)
    {
        time_counter = 0;

        while (time_counter < reloadTimeInSeconds)
        {
            time_counter += Time.deltaTime;
            yield return null;
          //  Debug.Log(time_counter);
        }

        //Load new Scene
        SceneManager.LoadScene("End");
    }

    // Update is called once per frame
    void Update()
    {
      //  time_counter += Time.deltaTime;
      if(Input.GetKeyDown("q") == true)
      {
        SceneManager.LoadScene("End");
      }
    }
}
