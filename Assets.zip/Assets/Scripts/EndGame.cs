﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;


public class EndGame : MonoBehaviour
{
  [SerializeField] TMPro.TextMeshProUGUI TotalHits, NiceShots, GameTime;
    // Start is called before the first frame update
    public void Start()
    {
       TotalHits.text += TrackHits.hits;
       NiceShots.text += TrackHits.niceShots;
       GameTime.text += TrackTime.time_counter;

       int t_score = TrackHits.hits + 5 * TrackHits.niceShots ;


    }

}
