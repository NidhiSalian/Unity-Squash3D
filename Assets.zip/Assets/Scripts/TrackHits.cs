using System;
using System.Collections;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class TrackHits : MonoBehaviour
{
    public static int hits ;
    //public static int missedBalls;
  //  private IEnumerator DisplayHitNotification;
    [SerializeField]
    private GameObject HitNotification;
    [SerializeField]
    private GameObject ScoreTracker;
    public static int niceShots;

    void Start()
    {
      niceShots = 0;
      hits = 0;
    //  missedBalls = 0;
    }

    void Update()
    {
      if(SpawnAndShootBall.ballCount - hits > 10)
      {
        SceneManager.LoadScene("End");
      }
    }


    private void OnCollisionEnter(Collision collision)
    {
      if(collision.collider.gameObject.tag == "Ball")
      {
        Collided(collision);
        UpdateHitsDisplay();
      }

      //  hits++;
    }

    private void OnCollisionStay(Collision collision)
    {
      if(collision.collider.gameObject.tag == "Ball")
      {
        Collided(collision);
      }
    }

    void Collided(Collision collision)
    {
      StartCoroutine(DisplayHitNotification());
    }

    private IEnumerator DisplayHitNotification()
    {
      HitNotification.SetActive(true);
      HitNotification.GetComponent<AudioSource>().Play();
      yield return new WaitForSeconds (0.5f);
      HitNotification.SetActive(false);
    }

    public void UpdateHitsDisplay()
    {
      string scoreText = ScoreTracker.gameObject.GetComponent<Text>().text;
      int hits_old = Int32.Parse(Regex.Replace(scoreText, "[^0-9]", ""));
      //Debug.Log(hits_old + 1);

      hits = hits_old==0? 1 : hits_old + 1;
      ScoreTracker.gameObject.GetComponent<Text>().text = "HITS: " + hits;
    }


}
