﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class CollisionReactions : MonoBehaviour
{
    //private List<string> collisions_list = new List<string>();
    public int hitOnce;

    //[SerializeField]
    public Text ScoreIncreaseNotificationText;


    int FloorCollisionsRemaining ;
    int WallCollisionsRemaining ;
    int TotalCollisions ;
    // Start is called before the first frame update
    void Awake()
    {
      hitOnce = 0;
      FloorCollisionsRemaining = 1;
      WallCollisionsRemaining = 2;
      TotalCollisions = 5;
      //CollisionsRemaining = 4;
      GameObject ScoreIncreaseNotification = GameObject.Find("ScoreIncreaseNotification");
      ScoreIncreaseNotificationText = ScoreIncreaseNotification.GetComponent<Text>();
      ScoreIncreaseNotificationText.text = "";
    }

    // Update is called once per frame
    void Update()
    {

    }

    void OnCollisionEnter(Collision collision)
    {

    //  collisions_list.Add(collision.collider.gameObject.tag);

     if(collision.collider.gameObject.tag == "Player")
     {
       hitOnce++;
       FloorCollisionsRemaining = 2;
       TotalCollisions --;
     }
     else if(collision.collider.gameObject.tag == "frontwall")
      {
        if(hitOnce == 1)
        {
          StartCoroutine(DisplayScoreIncreaseNotification());
        }
         TotalCollisions = 0;
      }
     else if(collision.collider.gameObject.tag == "floor")
     {
       FloorCollisionsRemaining--;
       TotalCollisions--;
     }
     else
     {
       WallCollisionsRemaining --;
       TotalCollisions --;
     }

     if(TotalCollisions == 0 )
      Destroy(this.gameObject,3.0f);


    }

    private IEnumerator DisplayScoreIncreaseNotification()
    {
      ScoreIncreaseNotificationText.text = "NICE SHOT!";
      TrackHits.niceShots ++;
      yield return new WaitForSeconds (1.2f);
      ScoreIncreaseNotificationText.text = "";
    }


}
