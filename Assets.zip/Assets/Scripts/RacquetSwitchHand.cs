﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

public class RacquetSwitchHand : MonoBehaviour
{
    public enum Hands {Right = 0, Left =1};
    UnityEngine.Ray current_player_position;
    public GameObject racquet_left, racquet_right;
    public Hands active_hand;

    void Start()
    {
      racquet_left.SetActive(false);
      racquet_right.SetActive(false);
      if(active_hand == Hands.Right) racquet_right.SetActive(true);
      else racquet_left.SetActive(true);

    }

    void Update()
    {
        if(Input.GetKeyDown("space"))
        {
          if (active_hand == Hands.Right)
          {
            racquet_left.SetActive(true);
            racquet_right.SetActive(false);
            active_hand = Hands.Left;
          }
          else
          {
            racquet_right.SetActive(true);
            racquet_left.SetActive(false);
            active_hand = Hands.Right;

          }
        }


    }
 }
