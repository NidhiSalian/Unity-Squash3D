﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpawnAndShootBall : MonoBehaviour
{
    private float nextSpawnTime;
    public static int ballCount;
    private GameObject currentShooter;
    private GameObject newBall;
    [SerializeField]
    private GameObject ballPrefab;
    [SerializeField]
    private GameObject target;
    [SerializeField]
    private float spawnDelay = 1.0f;
    // Start is called before the first frame update
    void Start()
    {
      ballCount = 0;
    }

    private void Spawn()
    {
      nextSpawnTime = Time.time + spawnDelay;
      Debug.Log(nextSpawnTime);
      newBall = Instantiate(ballPrefab, currentShooter.transform.position, currentShooter.transform.rotation) as GameObject;
      ballCount ++;
      //newBall.AddComponent<Rigidbody>();
      AddForce();
    }

    private void AddForce()
    {
      Vector3 dir = target.transform.position - newBall.transform.position;
      int force = 300;
      dir = dir.normalized;
      newBall.GetComponent<Rigidbody>().AddForce(dir * force, ForceMode.Impulse);
    }

    private bool ShouldSpawn()
    {
      return Time.time >= nextSpawnTime;
    }

    // Update is called once per frame
    void Update()
    {
      int randomChild = Random.Range(0,transform.childCount);
      currentShooter = this.gameObject.transform.GetChild(randomChild).gameObject;

      if(ShouldSpawn())
      {
        Spawn();
      }
    }
}
